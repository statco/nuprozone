export const translations = {
  en: {
    nav: {
      home: "Home",
      about: "About",
      products: "Products",
      wholesale: "Wholesale",
      contact: "Contact",
      lang: "FR"
    },
    hero: {
      eyebrow: "Handcrafted in North America",
      headline: "Pure Goat's Milk Soap",
      subhead: "Wholesale & Export Ready",
      body: "Premium handmade soap bars crafted with fresh goat's milk, organic oils, and pure essential oils. Available in bulk for retailers, spas, and wellness brands worldwide.",
      cta: "Request Wholesale Info",
      cta2: "View Products"
    },
    trust: {
      t1: "Cruelty-Free",
      t2: "Sensitive Skin Approved",
      t3: "All-Natural Ingredients",
      t4: "Export Ready"
    },
    about: {
      eyebrow: "Our Story",
      headline: "Made with care. Crafted for skin.",
      body1: "NUPROZ goat's milk soap is handcrafted in North America using fresh goat's milk. Every bar is cold-process made, loaded with skin-nourishing fats, lactic acids, and vitamins that gently cleanse without stripping.",
      body2: "We supply wholesale buyers who demand quality their customers can feel — spas, natural health retailers, gift shops, and wellness brands across North America and beyond.",
      stat1: "100%",
      stat1label: "Natural Ingredients",
      stat2: "4 oz",
      stat2label: "Per Bar / 113g",
      stat3: "Bulk",
      stat3label: "Export Available"
    },
    ingredients: {
      eyebrow: "What's Inside",
      headline: "Clean. Simple. Effective.",
      body: "Every NUPROZ bar is made from a short list of purposeful ingredients — nothing synthetic, nothing unnecessary.",
      list: [
        { name: "Fresh Goat's Milk", desc: "Rich in alpha-hydroxy acids that gently exfoliate and hydrate all skin types." },
        { name: "Saponified Organic Oils", desc: "Olive, coconut, flaxseed and shea butter — cold-processed to retain skin benefits." },
        { name: "Pure Essential Oils", desc: "Naturally scented variants; fragrance-free options available for sensitive skin." },
        { name: "Organic Oats", desc: "Colloidal oat for soothing irritation and calming reactive skin." },
        { name: "Pure Honey", desc: "Natural humectant that draws moisture into the skin for lasting softness." }
      ]
    },
    products: {
      eyebrow: "Product Line",
      headline: "Current SKUs — Wholesale Catalogue",
      body: "Pricing, MOQs, and custom label options are available upon inquiry. New variants added seasonally.",
      coming: "Full product catalogue with pricing available upon inquiry — including private label options.",
      cta: "Request Catalogue"
    },
    why: {
      eyebrow: "Why NUPROZ",
      headline: "Built for buyers who care about what they sell.",
      items: [
        { title: "Private Label Ready", desc: "Custom labelling available for retailers and spa brands wanting their own identity." },
        { title: "Export Packaging", desc: "Bars individually wrapped and export-compliant for North America and international markets." },
        { title: "Consistent Quality", desc: "Every batch is cold-processed with fixed formulas — the bar your customer buys today will match the one they buy next season." },
        { title: "Cruelty-Free Certified", desc: "Never tested on animals. Sensitive-skin approved. Icons on all packaging." }
      ]
    },
    contact: {
      eyebrow: "Get in Touch",
      headline: "Request Wholesale Information",
      body: "Fill out the form below and we'll respond within 1–2 business days with pricing, MOQs, and catalogue details.",
      name: "Full Name",
      company: "Company / Business Name",
      email: "Email Address",
      phone: "Phone (optional)",
      country: "Country",
      message: "Message",
      messagePlaceholder: "Tell us about your business, estimated volume, and any product questions...",
      submit: "Send Inquiry",
      success: "Thank you! We'll be in touch within 1–2 business days.",
      error: "Something went wrong. Please email us at info@nuprozone.com",
      required: "Required"
    },
    footer: {
      tagline: "Handcrafted goat's milk soap. Made in North America. Shipped worldwide.",
      address: "Rouyn-Noranda, QC J9Y 1A8, Canada",
      email: "info@nuprozone.com",
      rights: "All rights reserved.",
      privacy: "Privacy Policy"
    }
  },
  fr: {
    nav: {
      home: "Accueil",
      about: "À propos",
      products: "Produits",
      wholesale: "Grossiste",
      contact: "Contact",
      lang: "EN"
    },
    hero: {
      eyebrow: "Artisanal en Amérique du Nord",
      headline: "Savon au Lait de Chèvre Pur",
      subhead: "Disponible en Gros et à l'Export",
      body: "Savons artisanaux haut de gamme fabriqués avec du lait de chèvre frais, des huiles biologiques et des huiles essentielles pures. Disponibles en vrac pour les détaillants, spas et marques de bien-être dans le monde entier.",
      cta: "Demander Info Grossiste",
      cta2: "Voir les Produits"
    },
    trust: {
      t1: "Sans Cruauté",
      t2: "Approuvé Peau Sensible",
      t3: "Ingrédients 100% Naturels",
      t4: "Prêt à l'Export"
    },
    about: {
      eyebrow: "Notre Histoire",
      headline: "Fabriqué avec soin. Formulé pour la peau.",
      body1: "Le savon au lait de chèvre NUPROZ est fabriqué à la main en Amérique du Nord avec du lait de chèvre frais. Chaque barre est élaborée à froid, riche en graisses nourrissantes, acides lactiques et vitamines qui nettoient en douceur.",
      body2: "Nous approvisionnons les acheteurs en gros qui exigent une qualité que leurs clients peuvent ressentir — spas, détaillants de santé naturelle, boutiques de cadeaux et marques de bien-être à travers l'Amérique du Nord et au-delà.",
      stat1: "100%",
      stat1label: "Ingrédients Naturels",
      stat2: "4 oz",
      stat2label: "Par Barre / 113g",
      stat3: "Vrac",
      stat3label: "Export Disponible"
    },
    ingredients: {
      eyebrow: "Ce Qu'il Y a Dedans",
      headline: "Pur. Simple. Efficace.",
      body: "Chaque barre NUPROZ est fabriquée à partir d'une courte liste d'ingrédients intentionnels — rien de synthétique, rien d'inutile.",
      list: [
        { name: "Lait de Chèvre Frais", desc: "Riche en acides alpha-hydroxy qui exfolient et hydratent doucement tous les types de peau." },
        { name: "Huiles Bio Saponifiées", desc: "Olive, noix de coco, lin et beurre de karité — traités à froid pour conserver les bienfaits." },
        { name: "Huiles Essentielles Pures", desc: "Variantes naturellement parfumées; options sans parfum disponibles pour les peaux sensibles." },
        { name: "Avoine Biologique", desc: "Avoine colloïdale pour apaiser l'irritation et calmer la peau réactive." },
        { name: "Miel Pur", desc: "Humectant naturel qui attire l'humidité dans la peau pour une douceur durable." }
      ]
    },
    products: {
      eyebrow: "Gamme de Produits",
      headline: "SKUs Actuels — Catalogue Grossiste",
      body: "Prix, MOQs et options d'étiquette personnalisée disponibles sur demande. Nouvelles variantes ajoutées chaque saison.",
      coming: "Catalogue produit complet avec tarifs disponible sur demande — incluant les options d'étiquette privée.",
      cta: "Demander le Catalogue"
    },
    why: {
      eyebrow: "Pourquoi NUPROZ",
      headline: "Conçu pour les acheteurs qui se soucient de ce qu'ils vendent.",
      items: [
        { title: "Étiquette Privée", desc: "Étiquetage personnalisé disponible pour les détaillants et marques spa." },
        { title: "Emballage Export", desc: "Barres emballées individuellement et conformes à l'export pour l'Amérique du Nord et les marchés internationaux." },
        { title: "Qualité Constante", desc: "Chaque lot est traité à froid avec des formules fixes — la barre achetée aujourd'hui correspondra à celle de la prochaine saison." },
        { title: "Certifié Sans Cruauté", desc: "Jamais testé sur les animaux. Approuvé peau sensible. Icônes sur tous les emballages." }
      ]
    },
    contact: {
      eyebrow: "Contactez-Nous",
      headline: "Demande d'Information Grossiste",
      body: "Remplissez le formulaire ci-dessous et nous vous répondrons dans 1 à 2 jours ouvrables avec les tarifs, les MOQs et les détails du catalogue.",
      name: "Nom Complet",
      company: "Entreprise / Nom Commercial",
      email: "Adresse Email",
      phone: "Téléphone (optionnel)",
      country: "Pays",
      message: "Message",
      messagePlaceholder: "Parlez-nous de votre entreprise, du volume estimé et de vos questions sur les produits...",
      submit: "Envoyer la Demande",
      success: "Merci! Nous vous contacterons dans 1 à 2 jours ouvrables.",
      error: "Une erreur s'est produite. Veuillez nous écrire à info@nuprozone.com",
      required: "Requis"
    },
    footer: {
      tagline: "Savon artisanal au lait de chèvre. Fabriqué en Amérique du Nord. Expédié dans le monde entier.",
      address: "Rouyn-Noranda, QC J9Y 1A8, Canada",
      email: "info@nuprozone.com",
      rights: "Tous droits réservés.",
      privacy: "Politique de Confidentialité"
    }
  }
};
